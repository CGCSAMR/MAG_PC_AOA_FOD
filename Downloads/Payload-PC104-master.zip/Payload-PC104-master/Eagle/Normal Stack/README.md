# Normal stack-PC104
This folder contains schematics and footprints of the PC104 standard for CubeSats' payloads with diferent dimension pad in the Stack component (only the pins used in SUCHAI project are edited)
