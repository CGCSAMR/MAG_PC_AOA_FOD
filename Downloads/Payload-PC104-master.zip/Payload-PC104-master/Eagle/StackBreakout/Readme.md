Readme - Stack Breakout

Stack Breakout - 4 capas

Historial

2020-08-12
Se incorpora conector con conexión I2C y UART.

2020-07-27 - V1.0
Se genera la placa de acuerdo a los diseños (dxf) enviados por Elías Obreque.
Se genera la placa usando cuatro capas
Se configurar parámetros genéricos (y más comunes) para el chequeo de errores (DRC - Design Rule Check)
